version = 3 -- Lua Version. Dont touch this
ScenarioInfo = {
    name = "Caldera",
    description = "Starving vultures peck over the dry, hot remains of countless battles fought atop this caldera. Map by Tanksy",
    preview = '',
    map_version = 15,
    type = 'skirmish',
    starts = true,
    size = {1024, 1024},
    reclaim = {307947.8, 104393},
    map = '/maps/Caldera/Caldera.scmap',
    save = '/maps/Caldera/Caldera_save.lua',
    script = '/maps/Caldera/Caldera_script.lua',
    norushradius = 48,
    Configurations = {
        ['standard'] = {
            teams = {
                {
                    name = 'FFA',
                    armies = {'ARMY_1', 'ARMY_2', 'ARMY_3', 'ARMY_4', 'ARMY_5', 'ARMY_6'}
                },
            },
            customprops = {
                ['ExtraArmies'] = STRING( 'ARMY_17 NEUTRAL_CIVILIAN' ),
            },
        },
    },
}
